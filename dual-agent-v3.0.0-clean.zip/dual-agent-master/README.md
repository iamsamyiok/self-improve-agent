# HWJ Agent — Self-Improving Agent Loop

一个零依赖 Node.js Agent Runtime：**内层 Agent 负责执行，外层 Agent 负责观察与改进，Evolution Engine 用可重复实验决定改进是否真的成立。**

> 核心原则：**修改不是改进，只有经过 Benchmark、Evaluator、Regression Guard 验证的候选版本，才有资格进入生产。**

## 1. 这版解决什么问题

旧式 Agent 的闭环通常是：

```text
任务 → Agent → 工具 → 结果
```

HWJ Agent 进一步形成：

```text
任务
 ↓
执行 Agent
 ↓
Execution / Experience
 ↓
Failure & Bottleneck Mining
 ↓
Meta Agent
 ↓
Improvement Hypothesis
 ↓
Mutation
 ↓
Sandbox Candidate
 ↓
Baseline vs Candidate
 ↓
Evaluation
 ↓
Regression Guard
 ↓
Promote / Reject
 ↓
新版本 Agent
 ↺
```

因此 Agent 不只是“自己改代码”，而是**通过实验选择自己的下一版本能力**。

## 2. 当前能力

### Agent Runtime

- OpenAI-compatible Chat API
- Tool Calling / Plugin Runtime
- Skill 渐进式加载
- 多工作区
- 会话持久化
- Context Compression
- 中断恢复
- 过程审计

### Memory

- 短期记忆
- 长期记忆
- 任务归档
- BM25 / 关键词检索
- Embedding 语义检索
- RRF 混合排序
- 自动 Recall / Archive

### Self-Improvement

- Experience Ledger
- Benchmark Dataset
- Failure Mining
- Improvement Hypothesis
- Candidate Mutation
- 独立 Sandbox Worker
- Baseline / Candidate A/B
- LLM Judge
- Objective Artifact Check
- Process Score
- Paired Benchmark Statistics
- Regression Guard
- Promote / Reject
- Snapshot / Rollback
- Evolution History / Leaderboard

### Web UI

2.2.0 对 Web UI 做了重新整理：

- 桌面端固定三栏工作区：插件 / 内层 Agent / 外层 Agent
- 统一间距、边框、按钮和字体层级
- 去除大面积渐变和过重阴影
- 插件列表独立滚动，不挤压聊天区域
- 中间聊天区始终作为视觉主体
- 外层评审与审批固定在右侧
- 弹窗、Diff、设置面板统一视觉语言
- 小屏自动切换为单面板聊天模式
- 保留原有 DOM ID 和 JS API，不破坏已有功能

## 3. 安装

要求 Node.js >= 18。

```bash
npm install
```

项目没有运行时 npm 依赖，主要使用 Node.js 内置模块。

## 4. 启动 Web UI

```bash
npm start
```

然后打开：

```text
http://127.0.0.1:3788/
```

如果端口被占用，可以：

```bash
DUAL_AGENT_PORT=3900 npm start
```

Windows PowerShell：

```powershell
$env:DUAL_AGENT_PORT=3900; npm start
```

## 5. 首次配置

打开 Web UI 后进入「设置」。

### 内层 LLM

填写：

```text
Base URL
API Key
Model
```

接口需要兼容 OpenAI Chat Completions / Responses 所使用的项目接口。

### Embedding（可选）

推荐使用 OpenAI-compatible Embedding API，例如：

```text
Base URL: https://api.siliconflow.cn/v1
Model: BAAI/bge-m3
```

没有 Embedding 时，Memory 会自动降级为关键词检索。

## 6. TUI

```bash
node hwj/hwj.js
```

或：

```bash
node hwj/hwj.js --ws default
```

单次任务：

```bash
node hwj/hwj.js --script "创建 hello.txt 并写入 Hello"
```

安静模式：

```bash
node hwj/hwj.js --script "读取 hello.txt" --quiet
```

## 7. Self-Improving Loop

### 建立经验

先正常执行一些真实任务：

```bash
hwj-agent run "你的任务"
```

成功任务会逐渐形成 Evolution Benchmark。

### 手动触发 Evolution

```bash
hwj-agent evolve
```

系统执行：

```text
Observe
 → Diagnose
 → Hypothesize
 → Mutate
 → Sandbox
 → Benchmark
 → Evaluate
 → Regression
 → Select
```

默认不会直接上线候选版本。

### Promote

```bash
hwj-agent evolve --promote
```

只有实验达到配置的统计门槛、没有严重 Regression，才允许 Promote。

### 自动 Evolution

```text
DUAL_AGENT_AUTO_EVOLVE=1
```

### 自动 Promote

```text
DUAL_AGENT_AUTO_EVOLVE=1
DUAL_AGENT_AUTO_PROMOTE=1
```

**建议先不要开启自动 Promote。**先积累足够多的真实 Benchmark，再让系统自动选择版本。

## 8. Evolution 数据

所有 Evolution 数据集中保存：

```text
.data/evolution/
├── benchmarks/
├── experiments/
├── agents/
├── versions/
├── experience.jsonl
├── leaderboard.json
└── state.json
```

一次实验至少包含：

```text
proposal
baseline
candidate
cases
metrics
evaluation
decision
promotion
```

所以每次进化都是**可追溯、可复盘、可比较、可回滚**的。

## 9. Evaluator

综合评价不依赖单一 LLM 判断：

```text
Final Score
 = Outcome
 + Objective Artifact Check
 + Process Metrics
```

同时对 Baseline / Candidate 使用相同 Benchmark，计算：

- mean delta
- standard deviation
- standard error
- 95% confidence lower bound
- win rate
- regression count

核心原则：

```text
局部提升 ≠ 全局提升
一次成功 ≠ 稳定提升
LLM 说更好 ≠ 实际更好
```

## 10. 安全边界

Self-Improvement 默认不是无限制修改自身。

候选版本在独立 workspace 中运行，经过验证后才能进入生产；生产变更保留 snapshot，可执行 rollback。

对于高风险修改，应继续使用人工 Gate。

## 11. 项目结构

```text
lib/
├── evolution.js          # Self-Improving 主循环
├── evolution-worker.js   # Sandbox 实验 Worker
├── regression.js         # 回归保护
├── inner.js              # 内层执行 Agent
├── outer.js              # 外层 Meta Agent
├── plugins.js            # Plugin Runtime
├── sdk.js                # SDK
└── ...

plugins/                  # Agent Tools
skills/                   # Agent Skills
hwj/                      # TUI
public/                   # Web UI
server.js                 # Web Server
test/                     # Smoke / Memory / Evolution Tests
docs/                     # 设计文档
```

## 12. 开发与验证

语法检查：

```bash
node --check lib/evolution.js
node --check lib/evolution-worker.js
node --check hwj/hwj.js
node --check server.js
```

Evolution Smoke Test：

```bash
node test/evolution-smoke.js
```

完整测试：

```bash
npm test
```

## 13. SDK

```js
const { chat, run, evolve } = require('hwj-agent');

const result = await run({
  message: '创建一个 hello.txt 文件并写入 Hello World'
});

await evolve();
```

## 14. 下一阶段

当前 Evolution 已经能够实验性修改：

```text
Plugin
Prompt
Skill
Strategy
Memory
```

下一阶段建议继续增加：

```text
Tool Selection Policy
Planning Policy
Verification Policy
Retrieval Policy
Automatic Task Curriculum
Cross-version Knowledge Transfer
```

最终目标不是“让 Agent 自己写更多代码”，而是：

> **让 Agent 根据长期任务结果持续发现自己的能力瓶颈，并用可重复实验选择更优策略。**

## License

MIT
